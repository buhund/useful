### Mac OS-version of Cache directory for World of Warcraft.

Workaround for:

* A Streaming Error has Occured.
* WOW51900322

Location:

World of Warcraft/Cache
